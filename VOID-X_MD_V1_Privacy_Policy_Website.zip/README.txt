# ᴠØɪᴅ-Ｘ ᴍᴅ ᴠ𝟷 — Privacy Policy

Files:
- index.html
- style.css
- script.js

## Before hosting

Open `index.html` and replace:
- `YOUR_EMAIL@example.com`
- `@YOUR_TELEGRAM_USERNAME`

with your real privacy contact details.

Then upload all three files to your hosting/public web directory.

The privacy policy is written for a Telegram + WhatsApp Multi-Device bot and should be checked against the bot's actual code, storage, APIs, hosting, and retention practices before publication.

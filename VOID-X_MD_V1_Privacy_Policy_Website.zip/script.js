// ᴠØɪᴅ-Ｘ ᴍᴅ ᴠ𝟷 Privacy Policy
// No tracking or analytics are included in this script.

document.addEventListener("DOMContentLoaded", () => {
  const links = document.querySelectorAll('.toc-card a[href^="#"]');

  links.forEach(link => {
    link.addEventListener("click", event => {
      const target = document.querySelector(link.getAttribute("href"));
      if (!target) return;

      event.preventDefault();
      target.scrollIntoView({ behavior: "smooth", block: "start" });
      history.replaceState(null, "", link.getAttribute("href"));
    });
  });
});
